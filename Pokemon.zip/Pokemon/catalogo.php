<html>
<head>
  <link rel="stylesheet" href="botstrap/css/bootstrap.css">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta charset="utf-8">
</head>
<body>
        <h1>Pokemon store</h1>
        <ul class="nav">
          <li> <a href= "index.html">Home</a></li>
          <li> <a href= "registrati.html">Registrati</a></li>
<li> <a href= "accedi.html">Accedi</a></li>
<li> <a href= "Cerca.html">Cerca</a></li>
  <ul>
    <div class ="container"  >
<?php
include("DBHelper.php");
$handle = new dbhelper();
$handle->connect();
$handle->Catalog();
?>
</body>
</html>
