<?
    $cn = mysql_connect("localhost", "root", "mysql");
    @mysql_select_db("Pokemon", $cn);
    $testo = $_POST['testo'];
?>
<html><head><title>Risultati della ricerca</title></head><body>
<p>
<b>Risultati della ricerca:</b>
<?
    if (!$testo)
    {
        echo "nessun risultato!";
    }
    else
    {
        echo $testo;
    }
?>
</p>
<?
    if (!$testo)
    {

echo "<p>Specificare un criterio di ricerca.</p>";

    }
    else
    {
      echo $testo;



        include('DBHelper.php');
        $db_handler = new DBHelper();
        $db_handler->connect();
        $db_handler->Cerca($testo);
        if ($quanti == 0)
        {

        }
        else
        {
            for($x=0; $x<$quanti; $x++)
            {
                $rs = mysql_fetch_row($query);
                $id = $rs[0];
                $titolo = $rs[1];

            }
        }
    }
?>
</body></html>
