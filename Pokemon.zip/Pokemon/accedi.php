
<?php

$email=$_POST['email'];
$password=$_POST['pass'];
include('DBHelper.php');
$dbstile= new DBHelper();
$dbstile->connect();
$dbstile->login($email,$password);


?>
