
<?php
$username=$_POST['name'];
$email=$_POST['email'];
$password=$_POST['pass'];
include('DBHelper.php');
$dbswag= new DBHelper();
$dbswag->connect();
$dbswag->Register($username, $password, $email);
?>
