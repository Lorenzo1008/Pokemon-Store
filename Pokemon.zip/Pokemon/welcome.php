<?php
session_start();

if(!$_SESSION['email'])
{

    header("Location: accedi.php");//redirect to login page to secure the welcome page without login access.
    echo $_SESSION['email'];
}

?>


<html>
<body>
<h1>BENVENUTO</h1>
</body>
</html>
